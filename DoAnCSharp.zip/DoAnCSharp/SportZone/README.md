# SportZone – Demo đặt sân (Web + Desktop dùng chung CSDL)

## Cấu trúc

| Project | Vai trò |
|---|---|
| `SportZone.Data` | Lớp dữ liệu: Entity + `SportZoneContext` (EF Core), chuỗi kết nối trong `DbConfig.cs` |
| `SportZone.Business` | Lớp nghiệp vụ: `DatSanService` (kiểm tra trùng lịch, tính tiền, xác nhận đơn), `TaiKhoanService` (đăng nhập) |
| `SportZone.Web` | Trang khách hàng (ASP.NET Core MVC): xem sân, tìm kiếm, đặt sân, tra cứu đơn |
| `SportZone.Desktop` | App nhân viên (WinForms): đăng nhập, xem đơn, xác nhận / từ chối |

Web và Desktop cùng gọi `SportZone.Business`, nên quy tắc nghiệp vụ chỉ viết một lần.

## Chuẩn bị

1. Cài SQL Server (bản Developer hoặc Express) và .NET SDK 8 trở lên.
2. Mở `SportZone.Data/DbConfig.cs`, kiểm tra `Server=`:
   - SQL Server Developer / bản mặc định: `Server=.`
   - SQL Server Express: `Server=.\\SQLEXPRESS`
3. Không cần chạy script SQL: lần chạy đầu tiên, chương trình tự tạo CSDL `SportZoneDB` kèm dữ liệu mẫu.

## Chạy

**Cách 1 – Visual Studio:** mở `SportZone.sln` → chuột phải Solution → *Configure Startup Projects…* → chọn *Multiple startup projects*, đặt `SportZone.Web` và `SportZone.Desktop` là **Start** → nhấn F5.

**Cách 2 – Terminal (VS Code):** mở 2 terminal tại thư mục `SportZone`:

```
dotnet run --project SportZone.Web
dotnet run --project SportZone.Desktop
```

Web chạy ở http://localhost:5080

Tài khoản Desktop: `nv01 / 123` (nhân viên) hoặc `admin / 123` (quản lý).

## Kịch bản demo

1. Desktop: đăng nhập `nv01 / 123`, để màn hình "Quản lý đơn đặt sân" mở.
2. Web: vào trang chủ → chọn "Sân 5A" → chọn ngày mai → chọn giờ 18:00, 2 giờ → nhập tên, SĐT → **Đặt sân**.
3. Trong vòng 5 giây, Desktop kêu chuông, đơn mới hiện màu vàng "Chờ xác nhận".
4. Web: trang chi tiết sân hiện ô 18:00–19:00 màu vàng; thử đặt lại 18:00 → bị báo trùng lịch.
5. Desktop: chọn đơn → **Xác nhận**.
6. Web: vào "Tra cứu đơn đặt", nhập SĐT → đơn đã chuyển sang "Đã xác nhận" (màu xanh).

## Ghi chú

- Giá giờ vàng 17h–21h = giá thường × 1,3.
- Mật khẩu nhân viên lưu dạng băm SHA256, không lưu mật khẩu gốc.
- Kiểm tra trùng lịch và lưu đơn nằm trong một transaction mức Serializable, nên 2 khách bấm đặt cùng lúc thì chỉ 1 người thành công.

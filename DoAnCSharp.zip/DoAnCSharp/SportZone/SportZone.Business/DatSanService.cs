using System.Data;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using SportZone.Data;
using SportZone.Data.Entities;

namespace SportZone.Business {
    //Toàn bộ nghiệp vụ đặt sân nằm ở đây.
    //Web và Desktop cùng gọi lớp này nên quy tắc chỉ viết một lần.
    public class DatSanService {
        public const int GioMoCua = 5;
        public const int GioDongCua = 23;
        public const int GioVangTu = 17;
        public const int GioVangDen = 21;
        public const decimal HeSoGioVang = 1.3m;
        public const int SoGioToiDa = 3;

        private readonly SportZoneContext _db;

        public DatSanService(SportZoneContext db) {
            _db = db;
        }

        //------------------ Tra cứu sân ------------------

        public List<LoaiSan> LayDanhSachLoaiSan() {
            return _db.LoaiSan.OrderBy(l => l.MaLoai).ToList();
        }

        //Tìm sân theo loại và từ khóa (bỏ trống thì lấy tất cả)
        public List<San> TimSan(int? maLoai, string tuKhoa) {
            var query = _db.San.Include(s => s.LoaiSan).AsQueryable();
            if (maLoai.HasValue) {
                query = query.Where(s => s.MaLoai == maLoai.Value);
            }
            if (!string.IsNullOrWhiteSpace(tuKhoa)) {
                string tk = tuKhoa.Trim();
                query = query.Where(s => s.TenSan.Contains(tk) || s.LoaiSan.TenLoai.Contains(tk));
            }
            return query.OrderBy(s => s.MaSan).ToList();
        }

        public San LaySan(int maSan) {
            return _db.San.Include(s => s.LoaiSan).FirstOrDefault(s => s.MaSan == maSan);
        }

        //Các đơn còn hiệu lực (chưa hủy/từ chối) của một sân trong một ngày
        public List<DatSan> LayLichTrongNgay(int maSan, DateTime ngay) {
            DateTime d = ngay.Date;
            return _db.DatSan
                .Where(x => x.MaSan == maSan && x.NgaySuDung == d
                         && x.TrangThai != TrangThaiDatSan.TuChoi && x.TrangThai != TrangThaiDatSan.DaHuy)
                .OrderBy(x => x.GioBatDau)
                .ToList();
        }

        //------------------ Quy tắc nghiệp vụ ------------------

        public static bool LaGioVang(int gio) {
            return gio >= GioVangTu && gio < GioVangDen;
        }

        //Tính tiền từng giờ: giờ vàng (17h-21h) nhân hệ số 1.3
        public static decimal TinhTien(decimal giaMoiGio, int gioBatDau, int gioKetThuc) {
            decimal tong = 0;
            for (int gio = gioBatDau; gio < gioKetThuc; gio++) {
                tong += LaGioVang(gio) ? giaMoiGio * HeSoGioVang : giaMoiGio;
            }
            return tong;
        }

        //Hai khoảng giờ [a1, a2) và [b1, b2) giao nhau khi a1 < b2 và a2 > b1
        public bool BiTrungLich(int maSan, DateTime ngay, int gioBatDau, int gioKetThuc) {
            DateTime d = ngay.Date;
            return _db.DatSan.Any(x => x.MaSan == maSan && x.NgaySuDung == d
                && x.TrangThai != TrangThaiDatSan.TuChoi && x.TrangThai != TrangThaiDatSan.DaHuy
                && gioBatDau < x.GioKetThuc && gioKetThuc > x.GioBatDau);
        }

        //------------------ Khách đặt sân (Web) ------------------

        public DatSan TaoDon(int maSan, DateTime ngay, int gioBatDau, int soGio, string hoTen, string sdt) {
            //1. Kiểm tra dữ liệu nhập
            hoTen = (hoTen ?? "").Trim();
            sdt = (sdt ?? "").Trim();
            if (hoTen.Length < 2) {
                throw new NghiepVuException("Vui lòng nhập họ tên.");
            }
            if (!Regex.IsMatch(sdt, @"^0\d{9}$")) {
                throw new NghiepVuException("Số điện thoại phải gồm 10 chữ số và bắt đầu bằng 0.");
            }
            if (soGio < 1 || soGio > SoGioToiDa) {
                throw new NghiepVuException($"Chỉ được đặt từ 1 đến {SoGioToiDa} giờ.");
            }
            int gioKetThuc = gioBatDau + soGio;
            if (gioBatDau < GioMoCua || gioKetThuc > GioDongCua) {
                throw new NghiepVuException($"Sân chỉ mở từ {GioMoCua}h đến {GioDongCua}h.");
            }
            DateTime d = ngay.Date;
            if (d < DateTime.Today || (d == DateTime.Today && gioBatDau <= DateTime.Now.Hour)) {
                throw new NghiepVuException("Không thể đặt khung giờ đã qua.");
            }

            var san = LaySan(maSan);
            if (san == null) {
                throw new NghiepVuException("Sân không tồn tại.");
            }
            if (san.TrangThai != "Hoạt động") {
                throw new NghiepVuException("Sân đang bảo trì, vui lòng chọn sân khác.");
            }

            //2. Kiểm tra trùng và lưu trong cùng một transaction
            //Mức Serializable khóa vùng dữ liệu vừa đọc, nên 2 người bấm đặt cùng lúc
            //thì chỉ 1 người thành công, người còn lại bị báo trùng.
            using var tran = _db.Database.BeginTransaction(IsolationLevel.Serializable);

            if (BiTrungLich(maSan, d, gioBatDau, gioKetThuc)) {
                throw new NghiepVuException("Khung giờ này đã có người đặt, vui lòng chọn giờ khác.");
            }

            //Khách cũ thì dùng lại theo số điện thoại, khách mới thì tạo mới
            var kh = _db.KhachHang.FirstOrDefault(k => k.SDT == sdt);
            if (kh == null) {
                kh = new KhachHang { HoTen = hoTen, SDT = sdt };
                _db.KhachHang.Add(kh);
            }

            var don = new DatSan {
                KhachHang = kh,
                MaSan = maSan,
                NgaySuDung = d,
                GioBatDau = gioBatDau,
                GioKetThuc = gioKetThuc,
                TienSan = TinhTien(san.LoaiSan.GiaMoiGio, gioBatDau, gioKetThuc),
                TrangThai = TrangThaiDatSan.ChoXacNhan,
                NgayTao = DateTime.Now
            };
            _db.DatSan.Add(don);
            _db.SaveChanges();
            tran.Commit();
            return don;
        }

        public DatSan LayDon(int maDatSan) {
            return _db.DatSan
                .Include(x => x.KhachHang)
                .Include(x => x.San).ThenInclude(s => s.LoaiSan)
                .FirstOrDefault(x => x.MaDatSan == maDatSan);
        }

        public List<DatSan> TraCuuTheoSdt(string sdt) {
            sdt = (sdt ?? "").Trim();
            return _db.DatSan
                .Include(x => x.San)
                .Include(x => x.KhachHang)
                .Where(x => x.KhachHang.SDT == sdt)
                .OrderByDescending(x => x.NgayTao)
                .ToList();
        }

        //------------------ Nhân viên xử lý (Desktop) ------------------

        //trangThai = null nghĩa là lấy tất cả
        public List<DatSan> LayDanhSachDon(string trangThai) {
            var query = _db.DatSan
                .AsNoTracking()
                .Include(x => x.KhachHang)
                .Include(x => x.San)
                .AsQueryable();
            if (!string.IsNullOrEmpty(trangThai)) {
                query = query.Where(x => x.TrangThai == trangThai);
            }
            return query.OrderByDescending(x => x.NgayTao).ToList();
        }

        public int DemDonChoXacNhan() {
            return _db.DatSan.Count(x => x.TrangThai == TrangThaiDatSan.ChoXacNhan);
        }

        public void XacNhan(int maDatSan, int maNV) {
            DoiTrangThai(maDatSan, maNV, TrangThaiDatSan.DaXacNhan);
        }

        public void TuChoi(int maDatSan, int maNV) {
            DoiTrangThai(maDatSan, maNV, TrangThaiDatSan.TuChoi);
        }

        private void DoiTrangThai(int maDatSan, int maNV, string trangThaiMoi) {
            var don = _db.DatSan.Find(maDatSan);
            if (don == null) {
                throw new NghiepVuException("Không tìm thấy đơn đặt sân.");
            }
            if (don.TrangThai != TrangThaiDatSan.ChoXacNhan) {
                throw new NghiepVuException($"Đơn này đang ở trạng thái \"{don.TrangThai}\", không thể xử lý nữa.");
            }
            don.TrangThai = trangThaiMoi;
            don.MaNVXuLy = maNV;
            _db.SaveChanges();
        }
    }
}

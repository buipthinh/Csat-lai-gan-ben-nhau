using System.Globalization;

namespace SportZone.Business {
    //Hàm định dạng hiển thị dùng chung cho Web và Desktop
    public static class DinhDang {
        private static readonly CultureInfo VietNam = new CultureInfo("vi-VN");

        public static string Tien(decimal soTien) {
            return soTien.ToString("N0", VietNam) + " đ";
        }

        public static string KhungGio(int gioBatDau, int gioKetThuc) {
            return $"{gioBatDau:00}:00 - {gioKetThuc:00}:00";
        }
    }
}

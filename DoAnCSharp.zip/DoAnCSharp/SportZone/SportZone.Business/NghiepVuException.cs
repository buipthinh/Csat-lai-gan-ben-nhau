namespace SportZone.Business {
    //Lỗi do vi phạm quy tắc nghiệp vụ (trùng lịch, nhập sai...).
    //Giao diện bắt lỗi này để hiện thông báo cho người dùng.
    public class NghiepVuException : Exception {
        public NghiepVuException(string thongBao) : base(thongBao) {
        }
    }
}

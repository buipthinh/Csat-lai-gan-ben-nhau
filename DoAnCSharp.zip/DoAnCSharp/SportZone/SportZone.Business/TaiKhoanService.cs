using System.Security.Cryptography;
using System.Text;
using SportZone.Data;
using SportZone.Data.Entities;

namespace SportZone.Business {
    public class TaiKhoanService {
        private readonly SportZoneContext _db;

        public TaiKhoanService(SportZoneContext db) {
            _db = db;
        }

        //Trả về nhân viên nếu đúng tài khoản/mật khẩu, sai thì ném NghiepVuException
        public NhanVien DangNhap(string tenDangNhap, string matKhau) {
            if (string.IsNullOrWhiteSpace(tenDangNhap) || string.IsNullOrWhiteSpace(matKhau)) {
                throw new NghiepVuException("Vui lòng nhập đầy đủ tài khoản và mật khẩu.");
            }

            string hash = BamMatKhau(matKhau);
            var nv = _db.NhanVien.FirstOrDefault(n => n.TenDangNhap == tenDangNhap.Trim() && n.MatKhauHash == hash);
            if (nv == null) {
                throw new NghiepVuException("Sai tài khoản hoặc mật khẩu.");
            }
            return nv;
        }

        //Băm mật khẩu bằng SHA256, trả về chuỗi hex chữ thường
        public static string BamMatKhau(string matKhau) {
            byte[] bytes = SHA256.HashData(Encoding.UTF8.GetBytes(matKhau));
            return Convert.ToHexString(bytes).ToLowerInvariant();
        }
    }
}

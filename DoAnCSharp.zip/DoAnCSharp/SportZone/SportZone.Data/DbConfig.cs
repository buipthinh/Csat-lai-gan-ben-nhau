namespace SportZone.Data {
    //Chuỗi kết nối dùng chung cho cả Web và Desktop.
    //Chỉ cần sửa ở đây là cả hai ứng dụng cùng trỏ về một CSDL.
    //Máy dùng SQL Server Express nên Server là .\SQLEXPRESS
    //Nếu cài bản Developer (instance mặc định) thì đổi thành "Server=."
    public static class DbConfig {
        public const string ConnectionString =
            "Server=.\\SQLEXPRESS;Database=SportZoneDB;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True";
    }
}

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SportZone.Data.Entities {
    public class DatSan {
        [Key]
        public int MaDatSan { get; set; }

        public int MaKH { get; set; }

        [ForeignKey(nameof(MaKH))]
        public KhachHang KhachHang { get; set; }

        public int MaSan { get; set; }

        [ForeignKey(nameof(MaSan))]
        public San San { get; set; }

        [Column(TypeName = "date")]
        public DateTime NgaySuDung { get; set; }

        //Giờ tính theo số nguyên, ví dụ 18 nghĩa là 18:00
        public int GioBatDau { get; set; }
        public int GioKetThuc { get; set; }

        [Precision(18, 0)]
        public decimal TienSan { get; set; }

        //Xem các giá trị trong lớp TrangThaiDatSan
        [Required, MaxLength(30)]
        public string TrangThai { get; set; }

        public DateTime NgayTao { get; set; }

        //Nhân viên đã xác nhận hoặc từ chối đơn (null khi chưa xử lý)
        public int? MaNVXuLy { get; set; }

        [ForeignKey(nameof(MaNVXuLy))]
        public NhanVien NhanVienXuLy { get; set; }
    }
}

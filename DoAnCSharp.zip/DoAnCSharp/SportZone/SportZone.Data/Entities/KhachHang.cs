using System.ComponentModel.DataAnnotations;

namespace SportZone.Data.Entities {
    public class KhachHang {
        [Key]
        public int MaKH { get; set; }

        [Required, MaxLength(100)]
        public string HoTen { get; set; }

        [Required, MaxLength(15)]
        public string SDT { get; set; }
    }
}

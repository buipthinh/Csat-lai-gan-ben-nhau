using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace SportZone.Data.Entities {
    public class LoaiSan {
        [Key]
        public int MaLoai { get; set; }

        [Required, MaxLength(100)]
        public string TenLoai { get; set; }

        //Giá thuê 1 giờ ở khung giờ thường
        [Precision(18, 0)]
        public decimal GiaMoiGio { get; set; }

        public List<San> DsSan { get; set; }
    }
}

using System.ComponentModel.DataAnnotations;

namespace SportZone.Data.Entities {
    public class NhanVien {
        [Key]
        public int MaNV { get; set; }

        [Required, MaxLength(100)]
        public string HoTen { get; set; }

        [Required, MaxLength(50)]
        public string TenDangNhap { get; set; }

        //Không lưu mật khẩu gốc, chỉ lưu chuỗi băm SHA256
        [Required, MaxLength(64)]
        public string MatKhauHash { get; set; }

        //"Quản lý" hoặc "Nhân viên"
        [Required, MaxLength(30)]
        public string VaiTro { get; set; }
    }
}

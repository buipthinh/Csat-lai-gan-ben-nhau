using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SportZone.Data.Entities {
    public class San {
        [Key]
        public int MaSan { get; set; }

        [Required, MaxLength(100)]
        public string TenSan { get; set; }

        public int MaLoai { get; set; }

        [ForeignKey(nameof(MaLoai))]
        public LoaiSan LoaiSan { get; set; }

        [MaxLength(500)]
        public string MoTa { get; set; }

        //"Hoạt động" hoặc "Bảo trì"
        [Required, MaxLength(30)]
        public string TrangThai { get; set; }
    }
}

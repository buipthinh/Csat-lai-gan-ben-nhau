using Microsoft.EntityFrameworkCore;
using SportZone.Data.Entities;

namespace SportZone.Data {
    public class SportZoneContext : DbContext {
        public DbSet<LoaiSan> LoaiSan { get; set; }
        public DbSet<San> San { get; set; }
        public DbSet<KhachHang> KhachHang { get; set; }
        public DbSet<NhanVien> NhanVien { get; set; }
        public DbSet<DatSan> DatSan { get; set; }

        //Desktop dùng constructor này: new SportZoneContext()
        public SportZoneContext() {
        }

        //Web dùng constructor này (được tạo qua Dependency Injection)
        public SportZoneContext(DbContextOptions<SportZoneContext> options) : base(options) {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
            if (!optionsBuilder.IsConfigured) {
                optionsBuilder.UseSqlServer(DbConfig.ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            //Số điện thoại khách và tên đăng nhập không được trùng
            modelBuilder.Entity<KhachHang>().HasIndex(k => k.SDT).IsUnique();
            modelBuilder.Entity<NhanVien>().HasIndex(n => n.TenDangNhap).IsUnique();

            //Không cho xóa dây chuyền: xóa sân/khách đang có đơn sẽ bị chặn
            foreach (var fk in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys())) {
                fk.DeleteBehavior = DeleteBehavior.Restrict;
            }

            //Dữ liệu mẫu để demo
            modelBuilder.Entity<LoaiSan>().HasData(
                new LoaiSan { MaLoai = 1, TenLoai = "Bóng đá mini 5 người", GiaMoiGio = 300000 },
                new LoaiSan { MaLoai = 2, TenLoai = "Bóng đá 7 người", GiaMoiGio = 500000 },
                new LoaiSan { MaLoai = 3, TenLoai = "Cầu lông", GiaMoiGio = 80000 },
                new LoaiSan { MaLoai = 4, TenLoai = "Pickleball", GiaMoiGio = 120000 }
            );

            modelBuilder.Entity<San>().HasData(
                new San { MaSan = 1, TenSan = "Sân 5A", MaLoai = 1, TrangThai = "Hoạt động", MoTa = "Cỏ nhân tạo, có đèn chiếu sáng ban đêm" },
                new San { MaSan = 2, TenSan = "Sân 5B", MaLoai = 1, TrangThai = "Hoạt động", MoTa = "Cỏ nhân tạo, gần khu gửi xe" },
                new San { MaSan = 3, TenSan = "Sân 7 Trung tâm", MaLoai = 2, TrangThai = "Hoạt động", MoTa = "Sân lớn, có khán đài nhỏ" },
                new San { MaSan = 4, TenSan = "Cầu lông 1", MaLoai = 3, TrangThai = "Hoạt động", MoTa = "Sân trong nhà, sàn thảm" },
                new San { MaSan = 5, TenSan = "Cầu lông 2", MaLoai = 3, TrangThai = "Bảo trì", MoTa = "Đang thay thảm mới" },
                new San { MaSan = 6, TenSan = "Pickleball 1", MaLoai = 4, TrangThai = "Hoạt động", MoTa = "Sân ngoài trời, có mái che" }
            );

            //Mật khẩu mẫu của cả hai tài khoản là "123" (đã băm SHA256)
            modelBuilder.Entity<NhanVien>().HasData(
                new NhanVien { MaNV = 1, HoTen = "Quản lý sân", TenDangNhap = "admin", VaiTro = "Quản lý",
                    MatKhauHash = "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3" },
                new NhanVien { MaNV = 2, HoTen = "Nhân viên lễ tân", TenDangNhap = "nv01", VaiTro = "Nhân viên",
                    MatKhauHash = "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3" }
            );
        }
    }
}

namespace SportZone.Data {
    //Các trạng thái của một đơn đặt sân, dùng chung cho Web và Desktop
    public static class TrangThaiDatSan {
        public const string ChoXacNhan = "Chờ xác nhận";
        public const string DaXacNhan = "Đã xác nhận";
        public const string TuChoi = "Từ chối";
        public const string DaHuy = "Đã hủy";
    }
}

namespace SportZone.Desktop {
    partial class FormDangNhap {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent() {
            lblTieuDe = new Label();
            lblTenDangNhap = new Label();
            txtTenDangNhap = new TextBox();
            lblMatKhau = new Label();
            txtMatKhau = new TextBox();
            btnDangNhap = new Button();
            btnThoat = new Button();
            lblGoiY = new Label();
            SuspendLayout();
            //
            //lblTieuDe
            //
            lblTieuDe.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.FromArgb(20, 83, 45);
            lblTieuDe.Location = new Point(20, 20);
            lblTieuDe.Name = "lblTieuDe";
            lblTieuDe.Size = new Size(340, 40);
            lblTieuDe.Text = "SportZone - Quản trị";
            lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
            //
            //lblTenDangNhap
            //
            lblTenDangNhap.Location = new Point(30, 80);
            lblTenDangNhap.Name = "lblTenDangNhap";
            lblTenDangNhap.Size = new Size(100, 25);
            lblTenDangNhap.Text = "Tài khoản";
            lblTenDangNhap.TextAlign = ContentAlignment.MiddleLeft;
            //
            //txtTenDangNhap
            //
            txtTenDangNhap.Location = new Point(130, 80);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.Size = new Size(220, 27);
            txtTenDangNhap.TabIndex = 0;
            txtTenDangNhap.Text = "nv01";
            //
            //lblMatKhau
            //
            lblMatKhau.Location = new Point(30, 120);
            lblMatKhau.Name = "lblMatKhau";
            lblMatKhau.Size = new Size(100, 25);
            lblMatKhau.Text = "Mật khẩu";
            lblMatKhau.TextAlign = ContentAlignment.MiddleLeft;
            //
            //txtMatKhau
            //
            txtMatKhau.Location = new Point(130, 120);
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.Size = new Size(220, 27);
            txtMatKhau.TabIndex = 1;
            txtMatKhau.UseSystemPasswordChar = true;
            //
            //btnDangNhap
            //
            btnDangNhap.BackColor = Color.FromArgb(21, 128, 61);
            btnDangNhap.FlatStyle = FlatStyle.Flat;
            btnDangNhap.ForeColor = Color.White;
            btnDangNhap.Location = new Point(130, 165);
            btnDangNhap.Name = "btnDangNhap";
            btnDangNhap.Size = new Size(105, 35);
            btnDangNhap.TabIndex = 2;
            btnDangNhap.Text = "Đăng nhập";
            btnDangNhap.UseVisualStyleBackColor = false;
            btnDangNhap.Click += btnDangNhap_Click;
            //
            //btnThoat
            //
            btnThoat.Location = new Point(245, 165);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(105, 35);
            btnThoat.TabIndex = 3;
            btnThoat.Text = "Thoát";
            btnThoat.Click += btnThoat_Click;
            //
            //lblGoiY
            //
            lblGoiY.ForeColor = Color.Gray;
            lblGoiY.Location = new Point(20, 215);
            lblGoiY.Name = "lblGoiY";
            lblGoiY.Size = new Size(340, 25);
            lblGoiY.Text = "Tài khoản mẫu: admin / 123 hoặc nv01 / 123";
            lblGoiY.TextAlign = ContentAlignment.MiddleCenter;
            //
            //FormDangNhap
            //
            AcceptButton = btnDangNhap;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(380, 255);
            Controls.Add(lblTieuDe);
            Controls.Add(lblTenDangNhap);
            Controls.Add(txtTenDangNhap);
            Controls.Add(lblMatKhau);
            Controls.Add(txtMatKhau);
            Controls.Add(btnDangNhap);
            Controls.Add(btnThoat);
            Controls.Add(lblGoiY);
            Font = new Font("Segoe UI", 9F);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "FormDangNhap";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Đăng nhập";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTieuDe;
        private Label lblTenDangNhap;
        private TextBox txtTenDangNhap;
        private Label lblMatKhau;
        private TextBox txtMatKhau;
        private Button btnDangNhap;
        private Button btnThoat;
        private Label lblGoiY;
    }
}

using SportZone.Business;
using SportZone.Data;

namespace SportZone.Desktop {
    public partial class FormDangNhap : Form {
        public FormDangNhap() {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e) {
            try {
                using var db = new SportZoneContext();
                var nv = new TaiKhoanService(db).DangNhap(txtTenDangNhap.Text, txtMatKhau.Text);

                //Đăng nhập đúng: ẩn form đăng nhập, mở màn hình quản lý đơn
                Hide();
                using (var f = new FormDonDatSan(nv)) {
                    f.ShowDialog();
                }
                Close();
            }
            catch (NghiepVuException ex) {
                MessageBox.Show(ex.Message, "Đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMatKhau.Clear();
                txtMatKhau.Focus();
            }
            catch (Exception ex) {
                MessageBox.Show("Không kết nối được CSDL:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e) {
            Close();
        }
    }
}

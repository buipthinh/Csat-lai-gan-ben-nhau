namespace SportZone.Desktop {
    partial class FormDonDatSan {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent() {
            components = new System.ComponentModel.Container();
            pnlTren = new Panel();
            lblXinChao = new Label();
            lblLoc = new Label();
            cboTrangThai = new ComboBox();
            btnLamMoi = new Button();
            btnXacNhan = new Button();
            btnTuChoi = new Button();
            dgvDon = new DataGridView();
            stsDuoi = new StatusStrip();
            lblSoDonCho = new ToolStripStatusLabel();
            lblThongBao = new ToolStripStatusLabel();
            tmrTuDong = new System.Windows.Forms.Timer(components);
            pnlTren.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDon).BeginInit();
            stsDuoi.SuspendLayout();
            SuspendLayout();
            //
            //pnlTren
            //
            pnlTren.BackColor = Color.FromArgb(20, 83, 45);
            pnlTren.Controls.Add(lblXinChao);
            pnlTren.Controls.Add(lblLoc);
            pnlTren.Controls.Add(cboTrangThai);
            pnlTren.Controls.Add(btnLamMoi);
            pnlTren.Controls.Add(btnXacNhan);
            pnlTren.Controls.Add(btnTuChoi);
            pnlTren.Dock = DockStyle.Top;
            pnlTren.Name = "pnlTren";
            pnlTren.Size = new Size(1000, 95);
            //
            //lblXinChao
            //
            lblXinChao.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblXinChao.ForeColor = Color.White;
            lblXinChao.Location = new Point(15, 10);
            lblXinChao.Name = "lblXinChao";
            lblXinChao.Size = new Size(600, 30);
            lblXinChao.Text = "Xin chào";
            //
            //lblLoc
            //
            lblLoc.ForeColor = Color.White;
            lblLoc.Location = new Point(15, 52);
            lblLoc.Name = "lblLoc";
            lblLoc.Size = new Size(75, 28);
            lblLoc.Text = "Trạng thái";
            lblLoc.TextAlign = ContentAlignment.MiddleLeft;
            //
            //cboTrangThai
            //
            cboTrangThai.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTrangThai.Location = new Point(95, 53);
            cboTrangThai.Name = "cboTrangThai";
            cboTrangThai.Size = new Size(170, 28);
            cboTrangThai.SelectedIndexChanged += cboTrangThai_SelectedIndexChanged;
            //
            //btnLamMoi
            //
            btnLamMoi.Location = new Point(280, 50);
            btnLamMoi.Name = "btnLamMoi";
            btnLamMoi.Size = new Size(100, 34);
            btnLamMoi.Text = "Làm mới";
            btnLamMoi.UseVisualStyleBackColor = true;
            btnLamMoi.Click += btnLamMoi_Click;
            //
            //btnXacNhan
            //
            btnXacNhan.BackColor = Color.FromArgb(34, 197, 94);
            btnXacNhan.FlatStyle = FlatStyle.Flat;
            btnXacNhan.ForeColor = Color.White;
            btnXacNhan.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnXacNhan.Location = new Point(395, 50);
            btnXacNhan.Name = "btnXacNhan";
            btnXacNhan.Size = new Size(120, 34);
            btnXacNhan.Text = "✔ Xác nhận";
            btnXacNhan.UseVisualStyleBackColor = false;
            btnXacNhan.Click += btnXacNhan_Click;
            //
            //btnTuChoi
            //
            btnTuChoi.BackColor = Color.FromArgb(220, 38, 38);
            btnTuChoi.FlatStyle = FlatStyle.Flat;
            btnTuChoi.ForeColor = Color.White;
            btnTuChoi.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnTuChoi.Location = new Point(525, 50);
            btnTuChoi.Name = "btnTuChoi";
            btnTuChoi.Size = new Size(120, 34);
            btnTuChoi.Text = "✖ Từ chối";
            btnTuChoi.UseVisualStyleBackColor = false;
            btnTuChoi.Click += btnTuChoi_Click;
            //
            //dgvDon
            //
            dgvDon.AllowUserToAddRows = false;
            dgvDon.AllowUserToDeleteRows = false;
            dgvDon.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDon.BackgroundColor = Color.White;
            dgvDon.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDon.Dock = DockStyle.Fill;
            dgvDon.MultiSelect = false;
            dgvDon.Name = "dgvDon";
            dgvDon.ReadOnly = true;
            dgvDon.RowHeadersVisible = false;
            dgvDon.RowTemplate.Height = 30;
            dgvDon.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDon.CellFormatting += dgvDon_CellFormatting;
            //
            //stsDuoi
            //
            stsDuoi.Items.AddRange(new ToolStripItem[] { lblSoDonCho, lblThongBao });
            stsDuoi.Name = "stsDuoi";
            //
            //lblSoDonCho
            //
            lblSoDonCho.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblSoDonCho.Name = "lblSoDonCho";
            lblSoDonCho.Text = "Đơn chờ xác nhận: 0";
            //
            //lblThongBao
            //
            lblThongBao.Name = "lblThongBao";
            lblThongBao.Spring = true;
            lblThongBao.TextAlign = ContentAlignment.MiddleRight;
            lblThongBao.Text = "Tự động kiểm tra đơn mới mỗi 5 giây";
            //
            //tmrTuDong
            //
            tmrTuDong.Interval = 5000;
            tmrTuDong.Tick += tmrTuDong_Tick;
            //
            //FormDonDatSan
            //
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 560);
            Controls.Add(dgvDon);
            Controls.Add(pnlTren);
            Controls.Add(stsDuoi);
            Font = new Font("Segoe UI", 9F);
            MinimumSize = new Size(800, 450);
            Name = "FormDonDatSan";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SportZone - Quản lý đơn đặt sân";
            FormClosing += FormDonDatSan_FormClosing;
            Load += FormDonDatSan_Load;
            pnlTren.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvDon).EndInit();
            stsDuoi.ResumeLayout(false);
            stsDuoi.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlTren;
        private Label lblXinChao;
        private Label lblLoc;
        private ComboBox cboTrangThai;
        private Button btnLamMoi;
        private Button btnXacNhan;
        private Button btnTuChoi;
        private DataGridView dgvDon;
        private StatusStrip stsDuoi;
        private ToolStripStatusLabel lblSoDonCho;
        private ToolStripStatusLabel lblThongBao;
        private System.Windows.Forms.Timer tmrTuDong;
    }
}

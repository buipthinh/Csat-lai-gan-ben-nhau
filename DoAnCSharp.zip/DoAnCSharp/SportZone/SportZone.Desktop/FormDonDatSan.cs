using System.Media;
using SportZone.Business;
using SportZone.Data;
using SportZone.Data.Entities;

namespace SportZone.Desktop {
    public partial class FormDonDatSan : Form {
        private const string TatCa = "Tất cả";

        private readonly NhanVien _nv;
        private int _soDonChoLanTruoc = -1;

        public FormDonDatSan(NhanVien nv) {
            InitializeComponent();
            _nv = nv;
        }

        private void FormDonDatSan_Load(object sender, EventArgs e) {
            lblXinChao.Text = $"Xin chào: {_nv.HoTen} ({_nv.VaiTro})";
            cboTrangThai.Items.AddRange(new object[] {
                TrangThaiDatSan.ChoXacNhan, TrangThaiDatSan.DaXacNhan, TrangThaiDatSan.TuChoi, TatCa
            });
            cboTrangThai.SelectedIndex = 0; //sự kiện SelectedIndexChanged sẽ tải danh sách
            tmrTuDong.Start();
        }

        //Tải danh sách đơn từ CSDL lên lưới
        private void TaiDanhSach() {
            try {
                int? maDangChon = LayMaDonDangChon();
                string loc = cboTrangThai.SelectedItem?.ToString();
                if (loc == TatCa) {
                    loc = null;
                }

                using var db = new SportZoneContext();
                var service = new DatSanService(db);
                var ds = service.LayDanhSachDon(loc);

                dgvDon.DataSource = ds.Select(d => new {
                    d.MaDatSan,
                    KhachHang = d.KhachHang.HoTen,
                    SDT = d.KhachHang.SDT,
                    San = d.San.TenSan,
                    Ngay = d.NgaySuDung.ToString("dd/MM/yyyy"),
                    KhungGio = DinhDang.KhungGio(d.GioBatDau, d.GioKetThuc),
                    TienSan = DinhDang.Tien(d.TienSan),
                    d.TrangThai,
                    NgayTao = d.NgayTao.ToString("dd/MM HH:mm:ss")
                }).ToList();
                DatTieuDeCot();
                ChonLaiDong(maDangChon);

                _soDonChoLanTruoc = service.DemDonChoXacNhan();
                lblSoDonCho.Text = $"Đơn chờ xác nhận: {_soDonChoLanTruoc}";
            }
            catch (Exception ex) {
                lblThongBao.Text = "Lỗi tải dữ liệu: " + ex.Message;
            }
        }

        private void DatTieuDeCot() {
            if (dgvDon.Columns.Count == 0) {
                return;
            }
            dgvDon.Columns["MaDatSan"].HeaderText = "Mã đơn";
            dgvDon.Columns["KhachHang"].HeaderText = "Khách hàng";
            dgvDon.Columns["SDT"].HeaderText = "SĐT";
            dgvDon.Columns["San"].HeaderText = "Sân";
            dgvDon.Columns["Ngay"].HeaderText = "Ngày";
            dgvDon.Columns["KhungGio"].HeaderText = "Khung giờ";
            dgvDon.Columns["TienSan"].HeaderText = "Tiền sân";
            dgvDon.Columns["TrangThai"].HeaderText = "Trạng thái";
            dgvDon.Columns["NgayTao"].HeaderText = "Thời điểm đặt";
        }

        private int? LayMaDonDangChon() {
            if (dgvDon.CurrentRow == null || !dgvDon.Columns.Contains("MaDatSan")) {
                return null;
            }
            return (int)dgvDon.CurrentRow.Cells["MaDatSan"].Value;
        }

        //Sau khi tải lại, chọn lại đúng dòng người dùng đang chọn
        private void ChonLaiDong(int? maDatSan) {
            if (maDatSan == null) {
                return;
            }
            foreach (DataGridViewRow row in dgvDon.Rows) {
                if ((int)row.Cells["MaDatSan"].Value == maDatSan.Value) {
                    dgvDon.CurrentCell = row.Cells["MaDatSan"];
                    return;
                }
            }
        }

        //Xử lý chung cho nút Xác nhận và Từ chối
        private void XuLyDon(bool xacNhan) {
            int? ma = LayMaDonDangChon();
            if (ma == null) {
                MessageBox.Show("Vui lòng chọn một đơn trong danh sách.", "Thông báo");
                return;
            }

            string hanhDong = xacNhan ? "XÁC NHẬN" : "TỪ CHỐI";
            if (MessageBox.Show($"{hanhDong} đơn #{ma}?", "Xác nhận thao tác",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) {
                return;
            }

            try {
                using var db = new SportZoneContext();
                var service = new DatSanService(db);
                if (xacNhan) {
                    service.XacNhan(ma.Value, _nv.MaNV);
                }
                else {
                    service.TuChoi(ma.Value, _nv.MaNV);
                }
                lblThongBao.Text = $"Đã {hanhDong.ToLower()} đơn #{ma} lúc {DateTime.Now:HH:mm:ss}";
                TaiDanhSach();
            }
            catch (NghiepVuException ex) {
                MessageBox.Show(ex.Message, "Không thể xử lý", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                TaiDanhSach();
            }
            catch (Exception ex) {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXacNhan_Click(object sender, EventArgs e) {
            XuLyDon(true);
        }

        private void btnTuChoi_Click(object sender, EventArgs e) {
            XuLyDon(false);
        }

        private void btnLamMoi_Click(object sender, EventArgs e) {
            TaiDanhSach();
        }

        private void cboTrangThai_SelectedIndexChanged(object sender, EventArgs e) {
            TaiDanhSach();
        }

        //Cứ 5 giây kiểm tra CSDL một lần, có đơn mới từ Web thì tải lại và báo chuông
        private void tmrTuDong_Tick(object sender, EventArgs e) {
            try {
                using var db = new SportZoneContext();
                int soDonCho = new DatSanService(db).DemDonChoXacNhan();
                if (soDonCho != _soDonChoLanTruoc) {
                    bool coDonMoi = soDonCho > _soDonChoLanTruoc;
                    TaiDanhSach();
                    if (coDonMoi) {
                        SystemSounds.Asterisk.Play();
                        lblThongBao.Text = $"Có đơn đặt sân mới từ Web lúc {DateTime.Now:HH:mm:ss}!";
                    }
                }
            }
            catch (Exception ex) {
                lblThongBao.Text = "Mất kết nối CSDL: " + ex.Message;
            }
        }

        //Tô màu dòng theo trạng thái
        private void dgvDon_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e) {
            if (e.RowIndex < 0 || !dgvDon.Columns.Contains("TrangThai")) {
                return;
            }
            string tt = dgvDon.Rows[e.RowIndex].Cells["TrangThai"].Value?.ToString();
            if (tt == TrangThaiDatSan.ChoXacNhan) {
                e.CellStyle.BackColor = Color.FromArgb(254, 243, 199);
            }
            else if (tt == TrangThaiDatSan.DaXacNhan) {
                e.CellStyle.BackColor = Color.FromArgb(220, 252, 231);
            }
            else {
                e.CellStyle.BackColor = Color.FromArgb(243, 244, 246);
            }
        }

        private void FormDonDatSan_FormClosing(object sender, FormClosingEventArgs e) {
            tmrTuDong.Stop();
        }
    }
}

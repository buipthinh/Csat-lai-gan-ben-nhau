using SportZone.Data;

namespace SportZone.Desktop {
    internal static class Program {
        [STAThread]
        static void Main() {
            ApplicationConfiguration.Initialize();

            //Tạo CSDL nếu chưa có (Web cũng làm việc này, ai chạy trước thì tạo)
            try {
                using var db = new SportZoneContext();
                db.Database.EnsureCreated();
            }
            catch (Exception ex) {
                MessageBox.Show(
                    "Không kết nối được SQL Server.\nKiểm tra chuỗi kết nối trong SportZone.Data/DbConfig.cs\n\n" + ex.Message,
                    "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new FormDangNhap());
        }
    }
}

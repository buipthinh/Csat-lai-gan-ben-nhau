using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using SportZone.Business;

namespace SportZone.Web.Controllers {
    public class DatSanController : Controller {
        private readonly DatSanService _service;

        public DatSanController(DatSanService service) {
            _service = service;
        }

        //Nhận form đặt sân từ trang chi tiết
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Tao(int maSan, string ngay, int gioBatDau, int soGio, string hoTen, string sdt) {
            try {
                //Ô chọn ngày của trình duyệt luôn gửi dạng yyyy-MM-dd
                if (!DateTime.TryParseExact(ngay, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime ngayDat)) {
                    throw new NghiepVuException("Ngày không hợp lệ.");
                }
                var don = _service.TaoDon(maSan, ngayDat, gioBatDau, soGio, hoTen, sdt);
                return RedirectToAction("ThanhCong", new { id = don.MaDatSan });
            }
            catch (NghiepVuException ex) {
                //Lỗi nghiệp vụ: quay lại trang sân và hiện thông báo
                TempData["Loi"] = ex.Message;
                TempData["HoTen"] = hoTen;
                TempData["SDT"] = sdt;
                return RedirectToAction("ChiTiet", "San", new { id = maSan, ngay });
            }
        }

        public IActionResult ThanhCong(int id) {
            var don = _service.LayDon(id);
            if (don == null) {
                return NotFound();
            }
            return View(don);
        }

        //Khách tra cứu đơn của mình bằng số điện thoại
        public IActionResult TraCuu(string sdt) {
            ViewBag.SDT = sdt;
            var ds = string.IsNullOrWhiteSpace(sdt) ? null : _service.TraCuuTheoSdt(sdt);
            return View(ds);
        }
    }
}

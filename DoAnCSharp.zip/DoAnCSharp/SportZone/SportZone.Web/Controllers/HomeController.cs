using Microsoft.AspNetCore.Mvc;
using SportZone.Business;

namespace SportZone.Web.Controllers {
    public class HomeController : Controller {
        private readonly DatSanService _service;

        //DatSanService được ASP.NET Core tự truyền vào (Dependency Injection)
        public HomeController(DatSanService service) {
            _service = service;
        }

        //Trang chủ: danh mục loại sân + tìm kiếm sân
        public IActionResult Index(int? maLoai, string tuKhoa) {
            ViewBag.DsLoai = _service.LayDanhSachLoaiSan();
            ViewBag.MaLoai = maLoai;
            ViewBag.TuKhoa = tuKhoa;
            var dsSan = _service.TimSan(maLoai, tuKhoa);
            return View(dsSan);
        }

        public IActionResult Error() {
            return Content("Đã có lỗi xảy ra. Vui lòng thử lại sau.");
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using SportZone.Business;
using SportZone.Web.Models;

namespace SportZone.Web.Controllers {
    public class SanController : Controller {
        private readonly DatSanService _service;

        public SanController(DatSanService service) {
            _service = service;
        }

        //Chi tiết sân + lưới lịch trong ngày + form đặt sân
        public IActionResult ChiTiet(int id, DateTime? ngay) {
            var san = _service.LaySan(id);
            if (san == null) {
                return NotFound();
            }
            DateTime ngayXem = (ngay ?? DateTime.Today).Date;
            var vm = new ChiTietSanViewModel {
                San = san,
                Ngay = ngayXem,
                Lich = _service.LayLichTrongNgay(id, ngayXem)
            };
            return View(vm);
        }
    }
}

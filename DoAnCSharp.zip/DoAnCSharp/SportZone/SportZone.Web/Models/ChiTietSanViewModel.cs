using SportZone.Data.Entities;

namespace SportZone.Web.Models {
    //Dữ liệu cho trang chi tiết sân: thông tin sân + lịch trong ngày đang xem
    public class ChiTietSanViewModel {
        public San San { get; set; }
        public DateTime Ngay { get; set; }
        public List<DatSan> Lich { get; set; }

        //Tìm đơn đang chiếm giờ "gio" (null nếu giờ đó còn trống)
        public DatSan DonTaiGio(int gio) {
            return Lich.FirstOrDefault(d => d.GioBatDau <= gio && gio < d.GioKetThuc);
        }

        //Giờ đã trôi qua trong hôm nay thì không cho đặt
        public bool DaQua(int gio) {
            return Ngay.Date < DateTime.Today || (Ngay.Date == DateTime.Today && gio <= DateTime.Now.Hour);
        }
    }
}

using SportZone.Business;
using SportZone.Data;

var builder = WebApplication.CreateBuilder(args);

//Đăng ký MVC và các lớp dùng chung qua Dependency Injection
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<SportZoneContext>();
builder.Services.AddScoped<DatSanService>();

var app = builder.Build();

//Tự tạo CSDL kèm dữ liệu mẫu nếu chưa có
using (var scope = app.Services.CreateScope()) {
    var db = scope.ServiceProvider.GetRequiredService<SportZoneContext>();
    db.Database.EnsureCreated();
}

if (!app.Environment.IsDevelopment()) {
    app.UseExceptionHandler("/Home/Error");
}

app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
